#include <iostream>
#include <string>
#include <windows.h>
#include <fstream>
using namespace std;
/*
===============================================================
        AIRPORT ONLINE TICKET BOOKING SYSTEM (C++ Project)
===============================================================
DESCRIPTION:
This project is a console-based Airport Ticket Booking System 
developed in C++. It allows passengers to book, view, update, 
and delete flight tickets with color-enhanced text output 
for a better user interface.

FEATURES:
1. Passenger Management:
   - Book tickets in Business Class or Normal Class.
   - Store passenger details such as Ticket ID, Name, 
     Flight Name, Departure Date, and Destination.

2. View Tickets:
   - Display all booked tickets with their details in 
     a structured format.
   - Each ticket includes booking status.

3. Update Ticket:
   - Modify existing ticket details (Name, Flight, Date, 
     Destination) using Ticket ID.

4. Delete Ticket:
   - Cancel and remove a ticket from the system 
     permanently by Ticket ID.

5. File Handling:
   - All tickets are saved in a "tickets.txt" file.
   - Tickets are automatically loaded from the file 
     when the program starts.
   - Ensures persistence of data between program runs.

6. Console UI with Colors:
   - Colored text output using Windows.h for better 
     readability (headings, prompts, and messages 
     are highlighted).

TECHNOLOGIES USED:
- C++ (OOP Concepts + File Handling)
- Windows.h (for console color management)
- Standard Template Library (basic usage)

LIMITATIONS:
- Ticket ID must be entered manually by the user.
- No validation for duplicate Ticket IDs.
- Only supports Windows console (due to color functions).

USE CASE:
This project demonstrates understanding of:
- File Handling in C++
- Structures
- Functions
- Menu-driven programs
- Console UI formatting

AUTHOR:
[Your Name]  
Date: [Add Date]  

===============================================================
*/


// Function to set text color
void setColor(int color) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}

// Ticket structure
struct Ticket {
    int ticketID;
    string passengerName;
    string flightName;
    string departureDate;
    string destination;
    bool isBooked;
};

// Save tickets to file
void saveTickets(Ticket tickets[], int ticketCount) {
    ofstream file("tickets.txt");
    for (int i = 0; i < ticketCount; i++) {
        file << tickets[i].ticketID << ","
             << tickets[i].passengerName << ","
             << tickets[i].flightName << ","
             << tickets[i].departureDate << ","
             << tickets[i].destination << ","
             << tickets[i].isBooked << endl;
    }
    file.close();
}

// Load tickets from file
int loadTickets(Ticket tickets[]) {
    ifstream file("tickets.txt");
    int count = 0;
    if (file.is_open()) {
        while (file >> tickets[count].ticketID) {
            file.ignore();
            getline(file, tickets[count].passengerName, ',');
            getline(file, tickets[count].flightName, ',');
            getline(file, tickets[count].departureDate, ',');
            getline(file, tickets[count].destination, ',');
            file >> tickets[count].isBooked;
            file.ignore();
            count++;
        }
        file.close();
    }
    return count;
}

// View Tickets
void viewTickets(Ticket tickets[], int ticketCount) {
    system("cls");
    setColor(11);
    cout << "=================================================\n";
    cout << "             WELCOME TO VIEW TICKETS             \n";
    cout << "=================================================\n\n";
    setColor(9);

    if (ticketCount == 0) {
        setColor(12);
        cout << "No tickets booked yet.\n";
        setColor(7);
    } else {
        for (int i = 0; i < ticketCount; i++) {
            setColor(9); cout << "Ticket ID: "; 
            setColor(10); cout << tickets[i].ticketID << endl;

            setColor(9); cout << "Passenger Name: "; 
            setColor(10); cout << tickets[i].passengerName << endl;

            setColor(9); cout << "Flight Name: "; 
            setColor(10); cout << tickets[i].flightName << endl;

            setColor(9); cout << "Departure Date: "; 
            setColor(10); cout << tickets[i].departureDate << endl;

            setColor(9); cout << "Destination: "; 
            setColor(10); cout << tickets[i].destination << endl;

            setColor(9); cout << "Booking Status: "; 
            setColor(10); cout << (tickets[i].isBooked ? "Booked" : "Not Booked") << endl;

            setColor(7);
            cout << "---------------------------------------------\n";
        }
    }
    system("pause");
}

// Book Ticket (Business/Normal)
void bookTicket(Ticket tickets[], int &ticketCount, string type) {
    system("cls");
    setColor(11);
    cout << "=================================================\n";
    cout << "         WELCOME TO " << type << " CLASS BOOKING        \n";
    cout << "=================================================\n\n";
    setColor(9);

    Ticket t;
    setColor(9); cout << "Enter Ticket ID: "; setColor(10); cin >> t.ticketID;
    cin.ignore();
    setColor(9); cout << "Enter Passenger Name: "; setColor(10); getline(cin, t.passengerName);
    setColor(9); cout << "Enter Flight Name: "; setColor(10); getline(cin, t.flightName);
    setColor(9); cout << "Enter Departure Date: "; setColor(10); getline(cin, t.departureDate);
    setColor(9); cout << "Enter Destination: "; setColor(10); getline(cin, t.destination);

    t.isBooked = true;
    tickets[ticketCount++] = t;
    saveTickets(tickets, ticketCount);

    setColor(10);
    cout << "\nTicket booked successfully!\n";
    setColor(7);
    system("pause");
}

// Update Ticket
void updateTicket(Ticket tickets[], int ticketCount) {
    system("cls");
    setColor(11);
    cout << "=================================================\n";
    cout << "              WELCOME TO UPDATE TICKET           \n";
    cout << "=================================================\n\n";
    setColor(9);

    int id;
    setColor(9); cout << "Enter Ticket ID to update: "; setColor(10); cin >> id;
    cin.ignore();

    bool found = false;
    for (int i = 0; i < ticketCount; i++) {
        if (tickets[i].ticketID == id) {
            found = true;
            setColor(9); cout << "Enter new Passenger Name: "; setColor(10); getline(cin, tickets[i].passengerName);
            setColor(9); cout << "Enter new Flight Name: "; setColor(10); getline(cin, tickets[i].flightName);
            setColor(9); cout << "Enter new Departure Date: "; setColor(10); getline(cin, tickets[i].departureDate);
            setColor(9); cout << "Enter new Destination: "; setColor(10); getline(cin, tickets[i].destination);
            saveTickets(tickets, ticketCount);
            setColor(10); cout << "\nTicket updated successfully!\n"; setColor(7);
            break;
        }
    }
    if (!found) {
        setColor(12); cout << "Ticket not found!\n"; setColor(7);
    }
    system("pause");
}

// Delete Ticket
void deleteTicket(Ticket tickets[], int &ticketCount) {
    system("cls");
    setColor(11);
    cout << "=================================================\n";
    cout << "              WELCOME TO DELETE TICKET           \n";
    cout << "=================================================\n\n";
    setColor(9);

    int id;
    setColor(9); cout << "Enter Ticket ID to delete: "; setColor(10); cin >> id;

    bool found = false;
    for (int i = 0; i < ticketCount; i++) {
        if (tickets[i].ticketID == id) {
            found = true;
            for (int j = i; j < ticketCount - 1; j++) {
                tickets[j] = tickets[j + 1];
            }
            ticketCount--;
            saveTickets(tickets, ticketCount);
            setColor(10); cout << "\nTicket deleted successfully!\n"; setColor(7);
            break;
        }
    }
    if (!found) {
        setColor(12); cout << "Ticket not found!\n"; setColor(7);
    }
    system("pause");
}

// Passenger Management
void passengerManagement(Ticket tickets[], int &ticketCount) {
    system("cls");
    setColor(11);
    cout << "=================================================\n";
    cout << "          WELCOME TO PASSENGER MANAGEMENT        \n";
    cout << "=================================================\n\n";
    setColor(14);

    cout << "1. Business Class\n";
    cout << "2. Normal Class\n";
    cout << "Enter choice: ";
    int choice; cin >> choice;

    if (choice == 1) {
        bookTicket(tickets, ticketCount, "BUSINESS");
    } else if (choice == 2) {
        bookTicket(tickets, ticketCount, "NORMAL");
    } else {
        setColor(12); cout << "Invalid choice!\n"; setColor(7);
        system("pause");
    }
}

// Main Menu
int main() {
    Ticket tickets[100];
    int ticketCount = loadTickets(tickets);

    int choice;
    do {
        system("cls");
        setColor(11);
        cout << "=================================================\n";
        cout << "         WELCOME TO ONLINE BOOKING SYSTEM        \n";
        cout << "=================================================\n\n";
        setColor(14);

        cout << "1. View Tickets\n";
        cout << "2. Passenger Management\n";
        cout << "3. Update Ticket\n";
        cout << "4. Delete Ticket\n";
        cout << "5. Exit\n";
        setColor(9);
        cout << "\nEnter your choice: ";
        setColor(7);
        cin >> choice;

        switch (choice) {
            case 1: viewTickets(tickets, ticketCount); break;
            case 2: passengerManagement(tickets, ticketCount); break;
            case 3: updateTicket(tickets, ticketCount); break;
            case 4: deleteTicket(tickets, ticketCount); break;
            case 5: 
                setColor(10);
                cout << "\nThank you for using the system!\n";
                setColor(7);
                break;
            default: 
                setColor(12);
                cout << "Invalid choice!\n"; 
                setColor(7);
                system("pause");
        }
    } while (choice != 5);

    return 0;
}
