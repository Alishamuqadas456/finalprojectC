#include <iostream>
#include <string>
#include <windows.h>
#include <limits> 
using namespace std;
/* 
Author"Alisha Muqadas"
Snack Machine Console Application
Developed by a Software Engineering  student at Riphah International University, Islamabad.
Snack Machine Console Application in C++

Key Features:
- Admin Mode: Password protected area where admin can restock snacks, view available snacks, 
  check total sales balance, and reset the balance.
- Customer Mode: Allows customers to view snacks, purchase snacks, and get change if payment exceeds cost.
- Stock Management: Tracks snack inventory, prevents purchase if out of stock.
- Input Validation: Ensures valid inputs for menu choices, snack selection, and restock quantities.
- Colorful Console Output: Uses Windows console color API for better UI/UX with different colors for prompts, errors, and info.
- Exit Option: User can exit at various points by entering '100' or choosing exit menu options.
*/
HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

void setColor(int color) {
    SetConsoleTextAttribute(hConsole, color);
}

struct Snack {
    string name;
    int price;
    int stock;
};

int totalBalance = 0;
const int MAX_RESTOCK = 50;

void clearScreen() {
    system("cls");
}

bool exitProgram(int choice) {
    if (choice == 100) {
        clearScreen();
        setColor(10); // Light green
        cout << "Exiting program..." << endl;
        setColor(7);
        return true;
    }
    return false;
}

void displaySnacks(Snack snacks[], int size) {
    clearScreen();
    setColor(3); // Cyan
    cout << "Available Snacks:" << endl;
    setColor(7); // Default

    for (int i = 0; i < size; ++i) {
        setColor(9); // Light blue for index
        cout << i << ". ";
        setColor(7);
        cout << snacks[i].name << " - $";
        setColor(14); // Yellow for price
        cout << snacks[i].price;
        setColor(7);
        cout << " (Stock: ";
        setColor(10); // Light green for stock
        cout << snacks[i].stock;
        setColor(7);
        cout << ")" << endl;
    }
    cout << "Press Enter to continue...";
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cin.get();
}

void restockSnack(Snack snacks[], int index) {
    clearScreen();
    setColor(14); // Yellow
    int quantity;
    cout << "Enter quantity to restock for " << snacks[index].name << " (Max " << MAX_RESTOCK << "): ";
    setColor(7);
    cin >> quantity;
    if (quantity > 0 && quantity <= MAX_RESTOCK) {
        snacks[index].stock += quantity;
        setColor(10); // Light green
        cout << "Restocked " << quantity << " units of " << snacks[index].name << "." << endl;
    } else {
        setColor(12); // Light red
        cout << "Invalid quantity!" << endl;
    }
    setColor(7);
    cout << "Press Enter to continue...";
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cin.get();
}

void purchaseSnack(Snack snacks[], int size) {
    clearScreen();
    setColor(3); // Cyan title
    cout << "Purchase Snack" << endl;
    setColor(7);

    int totalCost = 0;
    int totalPaid = 0;
    char anotherPurchase;
    do {
        setColor(14);
        int snackIndex;
        cout << "Enter snack number to purchase (0 to " << size - 1 << "): ";
        setColor(7);
        cin >> snackIndex;
        if (snackIndex >= 0 && snackIndex < size) {
            if (snacks[snackIndex].stock > 0) {
                snacks[snackIndex].stock--;
                totalCost += snacks[snackIndex].price;
                setColor(10);
                cout << "You added " << snacks[snackIndex].name << " for $" << snacks[snackIndex].price << "." << endl;
            } else {
                setColor(12);
                cout << "Sorry, " << snacks[snackIndex].name << " is out of stock!" << endl;
            }
        } else {
            setColor(12);
            cout << "Invalid snack number!" << endl;
        }
        setColor(7);
        cout << "Do you want to add another item? (y/n): ";
        cin >> anotherPurchase;
    } while (anotherPurchase == 'y' || anotherPurchase == 'Y');

    setColor(14);
    cout << "Total cost: $";
    setColor(7);
    cout << totalCost << endl;

    setColor(14);
    cout << "Enter amount to pay: $";
    setColor(7);
    cin >> totalPaid;

    if (totalPaid >= totalCost) {
        totalBalance += totalCost;
        int change = totalPaid - totalCost;
        setColor(10);
        cout << "You paid $" << totalPaid << ". Your change is $" << change << "." << endl;
        cout << "Thank you for your purchase!" << endl;
    } else {
        setColor(12);
        cout << "Insufficient funds!" << endl;
    }
    setColor(7);
    cout << "Press Enter to continue...";
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cin.get();
}

void checkBalance() {
    clearScreen();
    setColor(3);
    cout << "Total balance from customer purchases: $" << totalBalance << endl;
    setColor(7);
    cout << "Press Enter to continue...";
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cin.get();
}

void resetBalance() {
    clearScreen();
    totalBalance = 0;
    setColor(3);
    cout << "Total balance has been reset to $0." << endl;
    setColor(7);
    cout << "Press Enter to continue...";
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cin.get();
}

void adminMode(Snack snacks[], int size) {
    int adminChoice;
    do {
        clearScreen();
        setColor(3); // Cyan title
        cout << "                            Admin Mode                                        " << endl;
        setColor(14); // Yellow menu options
        cout << "                             1. Restock Snack                                " << endl;
        cout << "                             2. View Snacks                                  " << endl;
        cout << "                             3. Check Total Balance                          " << endl;
        cout << "                             4. Reset Total Balance                          " << endl;
        cout << "                             5. Back to Main Menu                            " << endl;
        setColor(7);

        cin >> adminChoice;
        if (exitProgram(adminChoice)) break;

        switch (adminChoice) {
            case 1: {
                setColor(14);
                int snackIndex;
                cout << "Enter snack number to restock (0 to " << size - 1 << "): ";
                setColor(7);
                cin >> snackIndex;
                if (snackIndex >= 0 && snackIndex < size) {
                    restockSnack(snacks, snackIndex);
                } else {
                    setColor(12);
                    cout << "Invalid snack number!" << endl;
                    setColor(7);
                }
                break;
            }
            case 2:
                displaySnacks(snacks, size);
                break;
            case 3:
                checkBalance();
                break;
            case 4:
                resetBalance();
                break;
            case 5:
                setColor(10);
                cout << "Returning to main menu..." << endl;
                setColor(7);
                break;
            default:
                setColor(12);
                cout << "Invalid choice, try again!" << endl;
                setColor(7);
        }

    } while (adminChoice != 5);
}

void customerMode(Snack snacks[], int size) {
    int customerChoice;
    do {
        clearScreen();
        setColor(3); // Cyan title
        cout << "                      Customer Mode                           " << endl;
        setColor(14); // Yellow options
        cout << "                         1. View Snacks                      " << endl;
        cout << "                         2. Purchase Snack                   " << endl;
        cout << "                         3. Back to Main Menu                " << endl;
        setColor(7);

        cin >> customerChoice;
        if (exitProgram(customerChoice)) break;

        switch (customerChoice) {
            case 1:
                displaySnacks(snacks, size);
                break;
            case 2:
                purchaseSnack(snacks, size);
                break;
            case 3:
                setColor(10);
                cout << "Returning to main menu..." << endl;
                setColor(7);
                break;
            default:
                setColor(12);
                cout << "Invalid choice, try again!" << endl;
                setColor(7);
        }
    } while (customerChoice != 3);
}

// New function for welcome page
int welcomePage() {
    int choice;
    do {
        clearScreen();
        setColor(11); // Light cyan background, bright text (you can adjust)
        cout << "                     ===============================" << endl;
        cout << "                         Welcome to Snack Machine  " << endl;
        cout << "                     ===============================" << endl;
        setColor(14); // Yellow
        cout << "                         Choose your mode:" << endl;
        cout << "                            1. Admin Mode" << endl;
        cout << "                            2. Customer Mode" << endl;
        cout << "                            3. Exit" << endl;
        setColor(7);
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice < 1 || choice > 3) {
            setColor(12);
            cout << "Invalid choice, please try again." << endl;
            setColor(7);
            cout << "Press Enter to continue...";
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cin.get();
        }
    } while (choice < 1 || choice > 3);
    return choice;
}

int main() {
    const string ADMIN_PASSWORD = "123";

    Snack snacks[] = {
        {"Chips", 10, 5},
        {"Soda", 15, 5},
        {"Chocolate", 20, 5},
        {"Candy Bar", 12, 5},
        {"Cookies", 18, 5},
        {"Gum", 5, 5}
    };

    int size = sizeof(snacks) / sizeof(snacks[0]);

    while (true) {
        int choice = welcomePage();
        if (choice == 3) {
            clearScreen();
            setColor(10);
            cout << "Thank you for using the Snack Machine. Goodbye!" << endl;
            setColor(7);
            break;
        }

        if (choice == 1) {
            setColor(14);
            string password;
            cout << "Enter admin password: ";
            setColor(7);
            cin >> password;
            if (password == ADMIN_PASSWORD) {
                adminMode(snacks, size);
            } else {
                setColor(12);
                cout << "Incorrect password!" << endl;
                setColor(7);
                cout << "Press Enter to continue...";
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cin.get();
            }
        } else if (choice == 2) {
            customerMode(snacks, size);
        }
    }

    return 0;
}
